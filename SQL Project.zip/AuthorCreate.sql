CREATE TABLE Author (
    LastName NVARCHAR NOT NULL,
	FirstName NVARCHAR NOT NULL,
	AddressLine1 NVARCHAR NOT NULL,
	AuthorID DECIMAL NOT NULL, 
    City NVARCHAR NOT NULL,
    State NVARCHAR NOT NULL,
    ZipCode DECIMAL  NOT NULL,
	RoyaltyPayments DECIMAL NOT NULL,
Primary key (AuthorID)
)
