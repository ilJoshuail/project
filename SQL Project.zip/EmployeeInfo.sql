INSERT INTO Employee(LastName, FirstName, AddressLine1, EmployeeID, City, State, ZipCode)
VALUES ('Michaels', 'Shawn','205 W Wallace Ave.', '000001', 'Tampa', 'Florida', '33573'),
	   ('Rahming', 'Gabriel','102 E Ocean Blvd.', '000002', 'Kingston', 'Jamaica', '73192'),
	   ('Rolle', 'Jacob','3425 Stone Street', '000003', 'Jacksonville', 'Florida', '39404'),
	   ('Phillip', 'Jamie','201 Market Street', '000004', 'San Fransisco', 'California', '30138'),
	   ('Lockhard', 'Jaelynn','423 Lombard Street', '000005', 'San Fransisco', 'California', '39412');