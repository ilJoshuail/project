INSERT INTO Customers(LastName, FirstName, AddressLine1, CustomerID, City, State, ZipCode)
VALUES ('Johnson', 'Kayla','123 East Rodeo Drive', '450021', 'Los Angeles', 'California', '90011'),
	   ('', '','  ', '', ' ', '', ''),
	   ('', '','  ', '', ' ', '', ''),
	   ('', '','  ', '', ' ', '', ''),
	   ('', '','  ', '', ' ', '', ''),