INSERT INTO Author(LastName, FirstName, AddressLine1, AuthorID, City, State, ZipCode, RoyaltyPayments)
VALUES ('Doug', 'Gilbert','11 S 59 E', '450021', 'Salt Lake City', 'Utah', '88776', '100'),
	   ('', '','', '', ' ', '', '', ''),
	   ('', '','', '', ' ', '', '', ''),
	   ('', '','', '', ' ', '', '', ''),
	   ('', '','', '', ' ', '', '', ''),