CREATE TABLE Royalties (
	AuthorID INT NOT NULL, 
    RoyaltyDate DATE NOT NULL,
    RoyaltyAmount INT NOT NULL,
    Primary key (AuthorID)
)
