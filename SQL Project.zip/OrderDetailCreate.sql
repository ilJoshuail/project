CREATE TABLE OrderDetail (
	SalesTrackingNumber DECIMAL NOT NULL, 
    ItemNumber DECIMAL NOT NULL,
    ID DECIMAL NOT NULL,
	Version NVARCHAR(30) NOT NULL,
	Quantity NVARCHAR(5) NOT NULL,
    Primary key (SalesTrackingNumber)
)
