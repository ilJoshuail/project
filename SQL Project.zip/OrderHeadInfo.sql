INSERT INTO OrderHead(SalesTrackingNumber, CustomerID, EmployeeID)
VALUES ('010', '450021', '000001'),
	   ('011', '450022', '000002'),
	   ('012', '450023', '000003'),
	   ('013', '450024', '000004'),
	   ('014', '450025', '000005');