CREATE TABLE Software (
    Version NVARCHAR(30) NOT NULL,
	PhysicalLocation VARCHAR (50) NOT NULL,
	RevisionDate DATE NOT NULL,
	ID DECIMAL NOT NULL, 
    Primary key (ID)
)
