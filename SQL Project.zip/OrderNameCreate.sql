CREATE TABLE OrderHead (
	SalesTrackingNumber DECIMAL NOT NULL, 
    CustomerID DECIMAL NOT NULL,
    EmployeeID DECIMAL NOT NULL,
    Primary key (SalesTrackingNumber)
)
