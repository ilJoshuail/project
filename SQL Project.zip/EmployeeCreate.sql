CREATE TABLE Employee(
    LastName NVARCHAR(30) NOT NULL,
	FirstName NVARCHAR(30) NOT NULL,
	AddressLine1 NVARCHAR (30) NOT NULL,
	EmployeeID DECIMAL NOT NULL, 
    City NVARCHAR(30) NOT NULL,
    State NVARCHAR(30) NOT NULL,
    ZipCode DECIMAL  NOT NULL,
    Primary key (EmployeeID)
)
