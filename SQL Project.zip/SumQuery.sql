SELECT SUM(Quantity) as Sum_Quantity
FROM OrderDetail;